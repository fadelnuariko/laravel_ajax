<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Page Title</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="{{URL::asset('assets/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="{{URL::asset('assets/css/bootstrap-theme.min.css')}}">
  <link rel="stylesheet" href="{{URL::asset('assets/css/custom.css')}}">

  <script src="{{URL::asset('assets/js/jquery-3.4.1.min.js')}}"></script>
  <script src="{{URL::asset('assets/js/bootstrap.min.js')}}"></script>
</head>

<body>
  <div class="container">
    <!-- Navbar start -->
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
            aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">PartnerIklan.com</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#">Homepage</a></li>
            <li><a href="#">News</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                aria-expanded="false">Product<span class="caret"></span></a>
              <ul class="dropdown-menu  dropdown-menu-left">
                <li><a href="#">Google</a></li>
                <li><a href="#">Facebook Ads</a></li>
                <li><a href="#">SEO</a></li>
                <li><a href="#">Training</a></li>
              </ul>
            </li>
            <li><a href="#">Pemesanan</a></li>
            <li><a href="#">Kontak</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Navbar end -->

    <!-- Jumbotron header start -->
    <div class="jumbotron">
      <!-- content here -->
    </div>
    <!-- Jumbotron header end -->

    <!-- thumbnail  start -->
    <div class="row">

      <!-- Menu 1 -->
      <div class="col-md-3">
        <div class="thumbnail">
          <div class="caption text-center">
            <a href="#">
              <h3>Google AdWords</h3>
            </a>
          </div>
        </div>
      </div>

      <!-- Menu 2 -->
      <div class="col-md-3">
        <div class="thumbnail">
          <div class="caption text-center">
            <a href="#">
              <h3>Facebook Ads</h3>
            </a>
          </div>
        </div>
      </div>

      <!-- Menu 3 -->
      <div class="col-md-3">
        <div class="thumbnail">
          <div class="caption text-center">
            <a href="#">
              <h3>SEO</h3>
            </a>
          </div>
        </div>
      </div>

      <!-- Menu 4 -->
      <div class="col-md-3">
        <div class="thumbnail">
          <div class="caption text-center">
            <a href="#">
              <h3>Training</h3>
            </a>
          </div>
        </div>
      </div>
    </div>
    <!-- Thumbnail end -->

  </div>
  <!-- Container end -->

</body>

<!-- Container Content -->
<div class="container mt-3">

  <!-- Article 1 start -->
  <div class="row articles">
    <div class="col-md-3">
      <img class="img img-responsive" src="http://via.placeholder.com/290x176" alt="Boff-logo">
    </div>
    <div class="col-md-9">
      <h3>Google AdWords</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
        pariatur.
      </p>
      <button class="btn btn-lg btn-default pull-right mt-1">Read More</button>
    </div>
  </div>
  <!-- End 1rticle 1 -->

  <!-- Article 2 start -->
  <div class="row articles">
    <div class="col-md-9">
      <h3 class="">Google AdWords</h3>
      <div class="clearfix"></div>
      <p class="">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
        pariatur.
      </p>
      <button class="btn btn-lg btn-default pull-right mt-1">Read More</button>
    </div>
    <div class="col-md-3">
      <img class="img img-responsive" src="http://via.placeholder.com/290x176" alt="Boff-logo">
    </div>
  </div>
  <!-- Article 2 end -->

  <!-- Article 3 start -->
  <div class="row articles">
    <div class="col-md-3">
      <img class="img img-responsive" src="http://via.placeholder.com/290x176" alt="Boff-logo">
    </div>
    <div class="col-md-9">
      <h3>Google AdWords</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
        pariatur.
      </p>
      <button class="btn btn-lg btn-default pull-right mt-1">Read More</button>
    </div>
  </div>
  <!-- Article 3 end -->
<a style="margin-left:50%;margin-right:50%;" class="btn btn-primary center" href="/">Kembali</a>
</div>
<!-- Container Content -->


</html>