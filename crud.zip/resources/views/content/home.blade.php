@extends('layouts.main')

@section('content')
<div class="container">
        <div class="row">
                <div class="col s12">
                  <div class="card">
                    <div class="card-image">
                      <img src="{{URL::asset('assets/img/bg-welcome.jpg')}}">
                      <span class="card-title">Selamat Datang</span>
                    </div>
                    <div class="card-content">
                      <p>Aplikasi ini dibuat sebagai bahan penilaian terhadap saya untuk dapat menjadi karyawan Tonjoo sebagai Web Developer</p>
                    </div>
                    <div class="card-action ">
                    <a href="{{url('/data')}}">Buka List Data</a>
                    </div>
                  </div>
                </div>
              </div>
    </div>
@endsection
