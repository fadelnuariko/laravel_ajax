@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row">
        <div class="col s12">
            <button class="btn green waves-effect waves-dark add-div">Tambah</button>
            <div class="card">
                <div class="card-content">
                    <div class="row" id="row-div">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
