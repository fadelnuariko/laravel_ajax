$(document).ready(function(){

    $(".delete-data").click(function(e){
      e.preventDefault();
  
      var id = $(this).attr('data-id');
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.value) {
            $.ajax({
                type:'GET',
                url:'/data/delete/'+id,
                success:function(data){
                   if(data.status=="OK"){
                    console.log(data)
                    $('#tr_'+id).remove(); // Remove to table
        
                    Swal.fire('Success','Data berhasil update','success'); // Alert sukses 
        
                   }else{
                    Swal.fire('Unknown','Telah terjadi kesalahan','error');  
                   }
                }
             }); 
        }
      })     
    });
  });